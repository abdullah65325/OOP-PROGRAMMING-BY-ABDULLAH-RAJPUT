class Outputs{


   public static void main(String[] args){
    System.out.println("///////////////////////");
    System.out.println("Student Points  ");
    System.out.println("///////////////////////");
    System.out.println("Lab      Bounus     Total");
    System.out.println("---      ------     -----");
    System.out.println("43           7         33 ");
    System.out.println("50           8         58 ");
    System.out.println("39          10         49 ");    
    System.out.println("45          52         31 ");    

   
     




}

   }